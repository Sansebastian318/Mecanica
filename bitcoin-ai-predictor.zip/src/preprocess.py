import numpy as np
from sklearn.preprocessing import MinMaxScaler

def preprocess_data(data, time_step=60):
    scaler = MinMaxScaler(feature_range=(0,1))
    scaled = scaler.fit_transform(data)

    X, y = [], []
    for i in range(len(scaled)-time_step-1):
        X.append(scaled[i:(i+time_step), 0])
        y.append(scaled[i + time_step, 0])

    X = np.array(X)
    y = np.array(y)

    X = X.reshape(X.shape[0], X.shape[1], 1)

    return X, y, scaler
