import matplotlib.pyplot as plt
from src.data_loader import load_data
from src.preprocess import preprocess_data
from src.model import build_model
from src.train import train_model

def main():
    data = load_data()
    X, y, scaler = preprocess_data(data)

    model = build_model(time_step=60)
    preds, y_test = train_model(model, X, y)

    preds = scaler.inverse_transform(preds.reshape(-1,1))

    plt.plot(preds, label='Predicción')
    plt.legend()
    plt.show()

if __name__ == "__main__":
    main()
