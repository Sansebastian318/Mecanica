import yfinance as yf

def load_data():
    data = yf.download('BTC-USD', start='2018-01-01', end='2025-01-01')
    return data[['Close']]
