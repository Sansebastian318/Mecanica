# Bitcoin AI Predictor 🚀

Modelo de inteligencia artificial basado en LSTM para analizar y predecir el comportamiento del Bitcoin.

## 📊 Tecnologías
- Python
- TensorFlow / Keras
- Pandas
- Scikit-learn
- yFinance

## 📥 Instalación

```bash
git clone https://github.com/tuusuario/bitcoin-ai-predictor.git
cd bitcoin-ai-predictor
pip install -r requirements.txt
```

## ▶️ Uso

```bash
python main.py
```

## 📈 Resultados
El modelo entrena con datos históricos y genera una predicción del precio.

## ⚠️ Disclaimer
Este proyecto es solo educativo. No es asesoría financiera.
