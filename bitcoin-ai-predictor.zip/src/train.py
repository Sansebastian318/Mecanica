def train_model(model, X, y):
    split = int(len(X)*0.8)

    X_train, X_test = X[:split], X[split:]
    y_train, y_test = y[:split], y[split:]

    model.fit(X_train, y_train, epochs=10, batch_size=32)

    preds = model.predict(X_test)

    return preds, y_test
